#should be renamed config.py
smtp_config = {
    "host": "smtp.mycorp.org",
    "port": 587,
    "use_ssl": True,
    "username": "my_username",
    "password": "secret",
    "from_name": "Wi-Fi Access",
    "from_email": "WiFi.Access@mycorp.org",
    "logo_url": "https://cdn.mist.com/wp-content/uploads/logo.png",    
    "enable_qrcode": True    
}